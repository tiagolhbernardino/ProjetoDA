﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iTasks_ProjetoDA.Enums
{
    public enum EstadoAtual
    {
        ToDo = 0,
        Doing = 1,
        Done = 2
    }
}
