﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iTasks_ProjetoDA.Enums
{
    public enum Departamento
    {
        IT = 0,
        Marketing = 1,
        Administracao = 2
    }
}
